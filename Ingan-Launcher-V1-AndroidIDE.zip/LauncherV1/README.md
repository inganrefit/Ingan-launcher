# Ingan Launcher V1

A simple Android home launcher for testing on a physical Android phone.

## Phone-only build with AndroidIDE

1. Install AndroidIDE from a trusted source such as its GitHub Releases page.
2. Open AndroidIDE and allow its requested storage/build permissions.
3. Extract this ZIP into a normal folder on the phone, for example `Download/LauncherV1`.
4. In AndroidIDE choose **Open Project** and select the `LauncherV1` folder (the folder containing `settings.gradle`).
5. Let Gradle sync/download the Android build dependencies.
6. Choose **Run/Build APK** (debug APK).
7. Install the generated APK.
8. Android will ask which Home app to use. Select **Ingan Launcher** and choose **Always** if you want it as the default.

## V1 features

- Android HOME launcher role
- Clock and date
- Swipe up to open app drawer
- Search installed launcher apps
- Tap an app to launch it
- Back/Home returns to launcher

## If AndroidIDE reports a Gradle/JDK error

Open AndroidIDE build settings and use its available JDK 17. The project uses Android Gradle Plugin 8.5.2 and compile/target SDK 35.

## Important

This is an early prototype. Keep your existing launcher available until the new launcher has been tested. You can switch the default Home app back from Android Settings > Apps > Default apps > Home app.
