package com.ingandoit.launcher;

import android.app.*;import android.os.*;import android.content.*;import android.content.pm.*;import android.graphics.Color;import android.graphics.drawable.ColorDrawable;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, apps; EditText search; PackageManager pm; ArrayList<ResolveInfo> all=new ArrayList<>();
    @Override public void onCreate(Bundle b){super.onCreate(b); pm=getPackageManager(); showHome();}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(sp);t.setGravity(Gravity.CENTER);t.setPadding(12,12,12,12);return t;}
    void base(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,36,24,20);root.setBackgroundColor(Color.rgb(16,17,20));setContentView(root);}
    void showHome(){base(); Space top=new Space(this);root.addView(top,new LinearLayout.LayoutParams(1,0,1)); TextView clock=tv(new java.text.SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),54);root.addView(clock,new LinearLayout.LayoutParams(-1,80));
      TextView date=tv(new java.text.SimpleDateFormat("EEEE, d MMMM",Locale.getDefault()).format(new Date()),18);root.addView(date,new LinearLayout.LayoutParams(-1,50));
      TextView hint=tv("Swipe up for apps",15);hint.setTextColor(Color.LTGRAY);root.addView(hint,new LinearLayout.LayoutParams(-1,50));
      root.setOnTouchListener(new View.OnTouchListener(){float y;public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0)y=e.getY();if(e.getAction()==1&&y-e.getY()>100){showDrawer();return true;}return true;}});
    }
    void showDrawer(){base(); search=new EditText(this);search.setHint("Search apps");search.setHintTextColor(Color.GRAY);search.setTextColor(Color.WHITE);search.setSingleLine();search.setBackground(new ColorDrawable(Color.rgb(35,37,42)));root.addView(search,new LinearLayout.LayoutParams(-1,58));
      apps=new LinearLayout(this);apps.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this);sv.addView(apps);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
      TextView back=tv("‹  Home",16);root.addView(back,new LinearLayout.LayoutParams(-1,54));back.setOnClickListener(v->showHome());
      loadApps(""); search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){loadApps(s.toString());}public void afterTextChanged(android.text.Editable e){}});search.requestFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(search,InputMethodManager.SHOW_IMPLICIT);
    }
    void loadApps(String q){apps.removeAllViews();Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);all.clear();all.addAll(pm.queryIntentActivities(i,0));Collections.sort(all,(a,b)->a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));for(ResolveInfo r:all){String n=r.loadLabel(pm).toString();if(!n.toLowerCase().contains(q.toLowerCase()))continue;Button b=new Button(this);b.setAllCaps(false);b.setText(n);b.setTextColor(Color.WHITE);b.setGravity(Gravity.CENTER_VERTICAL);b.setCompoundDrawablesWithIntrinsicBounds(r.loadIcon(pm),null,null,null);b.setCompoundDrawablePadding(20);apps.addView(b,new LinearLayout.LayoutParams(-1,64));b.setOnClickListener(v->{try{Intent x=pm.getLaunchIntentForPackage(r.activityInfo.packageName);if(x!=null)startActivity(x);}catch(Exception e){Intent x=pm.getLaunchIntentForPackage(r.activityInfo.packageName);if(x!=null)startActivity(x);}});}}
    @Override public void onBackPressed(){showHome();}
}
